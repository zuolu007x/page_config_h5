declare namespace NodeJS {
    interface ProcessEnv {
        VITE_APP_URL: string
        // 其他环境变量
    }
}
